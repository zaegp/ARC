// 什麼時候用 unowned？
class Customer {
    let name: String
    var card: CreditCard?
    init(name: String) {
        self.name = name
    }
    deinit { print("\(name) is being deinitialized") }
}

class CreditCard {
    let number: UInt64
    unowned let customer: Customer
    init(number: UInt64, customer: Customer) {
        self.number = number
        self.customer = customer
    }
    deinit { print("Card #\(number) is being deinitialized") }
}

var john: Customer?

john = Customer(name: "John Appleseed")
john!.card = CreditCard(number: 1234_5678_9012_3456, customer: john!)
                        
john = nil
       

// 使用 unowned 可能會有的風險
class Parent {
    var name: String
    var child: Child?
    
    init(name: String) {
        self.name = name
        print("\(name) 被創建了")
    }
    
    deinit {
        print("\(name) 被釋放了")
    }
}

class Child {
    var name: String
    weak var parentWeak: Parent? // 使用 weak
    unowned var parentUnowned: Parent // 使用 unowned
    
    init(name: String, parentWeak: Parent, parentUnowned: Parent) {
        self.name = name
        self.parentWeak = parentWeak
        self.parentUnowned = parentUnowned
        print("\(name) 小孩被創建了")
    }
    
    deinit {
        print("\(name) 小孩被釋放了")
    }
}

var parent: Parent? = Parent(name: "Alice")

var child: Child? = Child(name: "Bob", parentWeak: parent!, parentUnowned: parent!)

parent = nil

if child?.parentWeak == nil {
    print("parentWeak 是 nil")
} else {
    print("parentWeak 仍然存在")
}

// 在這裡使用 child?.parentUnowned，會 crash
print(child?.parentUnowned)

child = nil

print("執行結束")
