// 強引用計數講解
class Person {
    let name: String
    init(name: String) { self.name = name }
    var apartment: Apartment?
    deinit { print("\(name) is being deinitialized") }
}


class Apartment {
    let unit: String
    init(unit: String) { self.unit = unit }
    var tenant: Person?
    deinit { print("Apartment \(unit) is being deinitialized") }
}

var john: Person?
var unit4A: Apartment?

john = Person(name: "John Appleseed") // Person 的引用計數：1
unit4A = Apartment(unit: "4A") // Apartment 的引用計數：1

john!.apartment = unit4A // Apartment 的引用計數：2
unit4A!.tenant = john // Person 的引用計數：2

john = nil // Person 的引用計數：1
unit4A = nil // Apartment 的引用計數：1
