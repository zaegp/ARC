// value type
struct Book {
    var title: String
    var author: String
    var pages: Int
}

var myBook = Book(title: "Swift Programming", author: "John Doe", pages: 300)
var otherBook = myBook
otherBook.pages = 350

print(myBook.pages)  // 輸出 300
print(otherBook.pages)  // 輸出 350
